<?php
	// Not needed for templated theme